from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score, matthews_corrcoef

def compute_metrics(y_true, y_pred, y_prob=None):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel() if len(set(y_true)) == 2 else (0, 0, 0, 0)
    
    metrics = {
        'Accuracy': accuracy_score(y_true, y_pred),
        'Precision': precision_score(y_true, y_pred, average='weighted'),
        'Sensitivity (Recall)': recall_score(y_true, y_pred, average='weighted'),
        'Specificity': tn / (tn + fp) if (tn + fp) > 0 else None,
        'F1 Score': f1_score(y_true, y_pred, average='weighted'),
        'AUC-ROC': roc_auc_score(y_true, y_prob, multi_class='ovo') if y_prob is not None else None,
        'FPR': fp / (fp + tn) if (fp + tn) > 0 else None,
        'FNR': fn / (fn + tp) if (fn + tp) > 0 else None,
        'MCC': matthews_corrcoef(y_true, y_pred)
    }

    return metrics