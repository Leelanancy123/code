import cv2
import numpy as np
import random

def augment_image(image):
    height, width = image.shape[:2]
    crop_size = min(height, width)
    x = random.randint(0, width - crop_size)
    y = random.randint(0, height - crop_size)
    cropped = image[y:y+crop_size, x:x+crop_size]
    rotated = cv2.rotate(cropped, random.choice([cv2.ROTATE_90_CLOCKWISE,
                                                 cv2.ROTATE_180,
                                                 cv2.ROTATE_90_COUNTERCLOCKWISE]))
    resized = cv2.resize(rotated, (224, 224))
    return resized