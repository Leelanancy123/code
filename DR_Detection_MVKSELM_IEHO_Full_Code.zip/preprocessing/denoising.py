import cv2
import numpy as np

def apply_gabor_filter(image, ksize=31, sigma=4.0, theta=1.0, lambd=10.0, gamma=0.5, psi=0):
    kernel = cv2.getGaborKernel((ksize, ksize), sigma, theta, lambd, gamma, psi)
    return cv2.filter2D(image, cv2.CV_8UC3, kernel)