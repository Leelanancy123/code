import cv2

def apply_clahe(image):
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    if len(image.shape) == 2:
        return clahe.apply(image)
    elif len(image.shape) == 3:
        channels = cv2.split(image)
        enhanced = [clahe.apply(channel) for channel in channels]
        return cv2.merge(enhanced)