import pywt
import numpy as np

def wavelet_denoise(image, wavelet='db1', level=2):
    coeffs = pywt.wavedec2(image, wavelet, level=level)
    coeffs_thresh = list(map(lambda x: tuple(pywt.threshold(i, value=30, mode='soft') for i in x), coeffs[1:]))
    return pywt.waverec2([coeffs[0]] + coeffs_thresh, wavelet)