import torch
import torch.nn as nn
import torchvision.models as models

class SpatialPyramidPooling(nn.Module):
    def __init__(self, pool_sizes=[1, 2, 4]):
        super(SpatialPyramidPooling, self).__init__()
        self.pool_sizes = pool_sizes

    def forward(self, x):
        b, c, h, w = x.size()
        pooled_outputs = []
        for pool_size in self.pool_sizes:
            kernel_size = (h // pool_size, w // pool_size)
            stride = kernel_size
            pooling = nn.AdaptiveMaxPool2d((pool_size, pool_size))
            pooled = pooling(x).view(b, -1)
            pooled_outputs.append(pooled)
        return torch.cat(pooled_outputs, dim=1)

class SAVN(nn.Module):
    def __init__(self, num_classes=4):
        super(SAVN, self).__init__()
        vgg = models.vgg16_bn(pretrained=True)
        self.features = vgg.features
        self.spp = SpatialPyramidPooling(pool_sizes=[1, 2, 4])
        self.fc1 = nn.Linear(512 * (1*1 + 2*2 + 4*4), 256)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(256, 128)
        self.output = nn.Linear(128, num_classes)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        x = self.features(x)
        x = self.spp(x)
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.output(x)
        return self.softmax(x)