import os
import numpy as np
import torch
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from PIL import Image
import glob

from models.savn import SAVN
from utils.evaluation import compute_metrics

# Define dataset path (update with correct SD-OCT dataset path)
OCTID_PATH = './data/OCTID/'  # placeholder
RETINAL_OCT_PATH = './data/RetinalOCT/'  # placeholder

# Load SD-OCT data - OCTID and Retinal OCT datasets
class OCTDataset(torch.utils.data.Dataset):
    def __init__(self, root_dir, transform=None):
        self.images = []
        self.labels = []
        self.transform = transform
        self.label_encoder = LabelEncoder()
        self.classes = sorted(os.listdir(root_dir))
        for label in self.classes:
            for img_path in glob.glob(os.path.join(root_dir, label, '*.jpeg')):
                self.images.append(img_path)
                self.labels.append(label)
        self.encoded_labels = self.label_encoder.fit_transform(self.labels)

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img = Image.open(self.images[idx]).convert('RGB').resize((224, 224))
        if self.transform:
            img = self.transform(img)
        return img, self.encoded_labels[idx]

# Transforms
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

# Load Dataset
dataset = OCTDataset(OCTID_PATH, transform=transform)
train_idx, test_idx = train_test_split(list(range(len(dataset))), test_size=0.2, random_state=42)
train_loader = DataLoader(torch.utils.data.Subset(dataset, train_idx), batch_size=64, shuffle=True)
test_loader = DataLoader(torch.utils.data.Subset(dataset, test_idx), batch_size=64, shuffle=False)

# Model Setup
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = SAVN(num_classes=len(dataset.classes)).to(device)
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9)

# Train Model
print("Training Started...")
model.train()
for epoch in range(100):
    total_loss = 0
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    print(f"Epoch {epoch+1}/100 - Loss: {total_loss/len(train_loader):.4f}")

# Test Model
print("Testing Started...")
model.eval()
y_true, y_pred, y_prob = [], [], []
with torch.no_grad():
    for images, labels in test_loader:
        images = images.to(device)
        outputs = model(images)
        probs = torch.softmax(outputs, dim=1).cpu().numpy()
        predictions = np.argmax(probs, axis=1)
        y_true.extend(labels.numpy())
        y_pred.extend(predictions)
        y_prob.extend(probs)

# Evaluate Metrics
metrics = compute_metrics(y_true, y_pred, np.array(y_prob))
print("Evaluation Results:")
for key, value in metrics.items():
    print(f"{key}: {value}")